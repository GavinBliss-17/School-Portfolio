#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <sstream>
#include <limits>

using namespace std;

class Grocer {
public:
    int grocerMenu();       // Function to display and handle menu options.
    int openFile();         // Function to read items from input file.
    void saveToFile();      // Function to save item frequencies to a file.

private:
    int choice = 0;               // Stores user's menu choice.
    map<string, int> itemFreq;    // Map to store item frequencies.
};

int Grocer::grocerMenu() {
    do {
        // Display the menu
        cout << "Corner Grocer App:" << endl;
        cout << "1. Search for Item" << endl;
        cout << "2. Item Frequencies" << endl;
        cout << "3. Histogram of Item Frequencies" << endl;
        cout << "4. Exit App" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        // Input validation
        while (cin.fail() || choice < 1 || choice > 4) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Enter choice (1-4): ";
            cin >> choice;
        }

        switch (choice) {
        case 1: {  // Search for specific item frequency
            string searchItem;
            cout << "Enter Item: ";
            cin >> searchItem;

            if (itemFreq.count(searchItem) > 0) {
                cout << searchItem << " " << itemFreq[searchItem] << endl;
            }
            else {
                cout << "Item has not been found" << endl;
            }
            break;
        }
        case 2: {  // Display frequencies of all items
            for (auto&& item : itemFreq) {
                cout << item.first << " - " << item.second << endl;
            }
            break;
        }
        case 3: {  // Display histogram of item frequencies
            for (auto&& item : itemFreq) {
                cout << item.first << " ";
                for (int i = 1; i <= item.second; i++) {
                    cout << "*";  // Print asterisks based on item frequency
                }
                cout << endl;
            }
            break;
        }
        case 4: {  // Exit the application
            cout << "Exiting App" << endl;
            break;
        }
        }
    } while (choice != 4);

    return 0;
}

int Grocer::openFile() {
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    if (!inputFile) {
        cout << "Error: Cannot Open Input File" << endl;
        return 1;
    }

    string line, word;
    // Parse each line from the file
    while (getline(inputFile, line)) {
        istringstream iss(line);
        // Parse each word from the line and update the frequency in the map
        while (iss >> word) {
            itemFreq[word]++;
        }
    }
    inputFile.close();

    return 0;
}

void Grocer::saveToFile() {
    ofstream outFS;
    outFS.open("frequency.dat");

    if (!outFS.is_open()) {
        cout << "Error: Could not open file - frequency.dat" << endl;
        return;
    }

    // Write each item and its frequency to the file
    for (auto&& item : itemFreq) {
        outFS << item.first << " - " << item.second << endl;
    }

    outFS.close();
}

int main() {
    Grocer g;

    g.openFile();              // Load item frequencies from the input file
    g.saveToFile();            // Save loaded data to a file immediately after loading
    g.grocerMenu();            // Start the main menu loop

    return 0;
}
